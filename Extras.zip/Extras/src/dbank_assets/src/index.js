import { dbank } from "../../declarations/dbank";

window.addEventListener("load", async function() {
   // console.log("ready for balance");
   const currentAmount = await dbank.checkBalance();
   document.getElementById("value").innerText = Math.round (currentAmount * 100) / 100;
});

// After the balance we can listen to when then user type in an amount to top up or 
//withdraw then we trigger the corresponding function in our main.mo to substract or add into the current balance (event listener).

document.querySelector("form").addEventListener("submit", async function (event) {
    event.preventDefault();

    //it smart to disable the submit button once clicked in order to indicate to the user this has been clicked.

    const button = event.target.querySelector("#submit-btn");

    const inputAmount = parseFloat(document.getElementById("input-amount").value);
    const outputAmount = parseFloat(document.getElementById("withdrawal-amount").value);

    button.setAttribute("disabled", true);

    //Callimg the topUp function while passing whatever amount the user enters from UI.
    if (document.getElementById("input-amount").value.length != 0) {
        await dbank.topUp(inputAmount);
    }

    if (document.getElementById("withdrawal-amount").value.length != 0) {
        await dbank.withDraw(outputAmount);
    }

    await dbank.compound();
    
    const currentAmount = await dbank.checkBalance();
   document.getElementById("value").innerText = Math.round (currentAmount * 100) / 100;
   
   document.getElementById("input-amount").value = "";
   document.getElementById("withdrawal-amount").value = "";
   button.removeAttribute("disabled");
});